from django.shortcuts import render
from django.http import HttpResponse  # <-- HTML
from django.shortcuts import render

# Create your views here.


def hello(request):
    # return HttpResponse('안녕하세요. Django!')

    # html = """<!doctype html>
    # <h1>제목1</h1>
    # <h1>제목1</h1>
    # <img src='https://e7.pngegg.com/pngimages/85/391/png-clipart-django-web-framework-software-framework-model-view-controller-python-django-text-rectangle.png' width='300'>
    # """

    # return HttpResponse(html)

    name = '홍길동'
    heros = ['고주몽', '이성계', '을지문덕']

    return render(request, 'hello/hello2.html',
                  {'name': name,
                   'address': '서울시 강서구 염창동',
                   'phone': '010-888-9999',
                   'heros': heros})
