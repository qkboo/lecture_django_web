from django.apps import AppConfig


class NaverConfig(AppConfig):
    name = 'naver'
