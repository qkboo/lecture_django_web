from django.shortcuts import render
from django.http import HttpResponse

import urllib.request
import urllib.parse

client_id = "____________"
client_secret = "yFkEc0JhVA"


def naver(req):

    encQuery = urllib.parse.quote('파이썬')
    # https://openapi.naver.com/v1/search/book
    book_url = "https://openapi.naver.com/v1/search/book?query=" + \
        encQuery + "&display=3&sort=count"

    request = urllib.request.Request(book_url)
    request.add_header("X-Naver-Client-Id", client_id)
    request.add_header("X-Naver-Client-Secret", client_secret)
    response = urllib.request.urlopen(request)
    rescode = response.getcode()
    if(rescode == 200):
        response_body = response.read()
        return HttpResponse(response_body.decode('utf-8'))
    else:
        print("Error Code:" + rescode)
