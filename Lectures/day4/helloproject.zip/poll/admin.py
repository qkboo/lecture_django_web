from django.contrib import admin
from poll.models import Question
from poll.models import Choice


# Register your models here.
admin.site.register(Question)
admin.site.register(Choice)
