from django.shortcuts import render
from django.http.response import HttpResponse
from poll.models import Question, Choice

# Create your views here.


def list(request):
    # return HttpResponse('Poll lists!')
    poll_list = Question.objects.all()
    return render(request,
                  'poll/list.html', {'polls': poll_list})


def choice(request, no):
    try:
        poll = Question.objects.get(pk=no)
        choice_list = Choice.objects.filter(question_id=no)

        return render(request, "poll/choice.html",
                      {"choice_list": choice_list,
                       'poll': poll})
    except Question.DoesNotExist:
        return HttpResponse('Poll item is not found!')
