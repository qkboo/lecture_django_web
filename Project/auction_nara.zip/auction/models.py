from django.db import models

# Create your models here.
class Auction_data(models.Model):
    case = models.CharField(max_length=100)
    usage = models.CharField(max_length=50)
    address = models.CharField(max_length=200)
    other = models.CharField(max_length=500)
    value = models.CharField(max_length=100)
    date = models.CharField(max_length=100)
    
    def __str__(self):
        return self.case

    