from django.shortcuts import render
from .models import Auction_data
from django.http import HttpResponse  # <-- HTML
# from django.views.generic.edit import FormView
from django.views.generic import View
import re

#from forms import Search_case_form

class Myview(View):
    def get(self,request):
        ad_city_li=[]
        obj=Auction_data.objects.values()
        for i in obj:
           ad_city_li.append(i["address"].split()[0])
           ad_city=list(set(ad_city_li))
        ad_city.remove("사용본거지")
        ad_city.remove("선적항")
        ad_city.remove("광구소재지")
        ad_city.remove("소재지")
        html = "auction/search_bar.html"
       
        return render (request, html, { "ad_city_li" : ad_city }) # get 방식 ? // 보여준다 ? 

def city_result(request):
    global checked_city
    checked_city=request.POST.getlist('citycheck')
    result_case=[]
    html= "auction/result.html"
    for i in checked_city:
        obj=Auction_data.objects.filter(address__icontains=i).values()       
        inst=[]
        for j in obj:
            if j["address"].split()[1] != ":" :
                inst.append(j["address"].split()[1])
        inst=list(set(inst))
        for gu in inst:
            result_case.append((gu,len(list(Auction_data.objects.filter(address__icontains=i).filter(address__icontains=gu)))))   
        

    
    return render (request, html, { "var": result_case })

def auction_list(request):
    A_L_result=request.POST.getlist('gucheck')
    maxmoney=request.POST.get('maxmoney')
    minmoney=request.POST.get('minmoney')
    
    A_L_list=[]
    moneymax=0
    moneymin=0
    if re.search("억", maxmoney):
        eok_start=re.search("억",maxmoney).start()
        moneymax += int(maxmoney[0:re.search("억",maxmoney).start()])*100000000 
        if re.search("천만원",maxmoney) :
            moneymax += int(maxmoney[eok_start+1:re.search("천만원",maxmoney).start()])*10000000
    elif bool(re.search("억", maxmoney))==False :
        if re.search("천만원",maxmoney) :
            moneymax += int(maxmoney[0:re.search("천만원",maxmoney).start()])*10000000

    if re.search("억", minmoney):
        eok_start=re.search("억",minmoney).start()
        moneymin += int(minmoney[0:re.search("억",minmoney).start()])*100000000 
        if re.search("천만원",minmoney) :
            moneymin += int(minmoney[eok_start+1:re.search("천만원",minmoney).start()])*10000000
    elif bool(re.search("억", minmoney))==False :
        if re.search("천만원",minmoney) :
            moneymin += int(minmoney[0:re.search("천만원",minmoney).start()])*10000000



    if maxmoney!="all" and minmoney!="all":         
        for c in checked_city:
            city_fitered=Auction_data.objects.filter(address__icontains=c)
            for i in A_L_result:
                obj=city_fitered.filter(address__icontains=i).order_by('usage').values()
                for j in obj:
                    esti_val=int("".join(j["value"].split()[0].split(",")))
                    if esti_val<=moneymax and esti_val>=moneymin :
                        a=re.search(r'\]',j["address"]).end()
                        A_L_list.append({"id": j["id"],"case":"\n".join(j["case"].split()) , "usage":j["usage"].split()[1] , "address": j["address"][0:a] ,"value":j["value"] , "date": j["date"] })
    
    elif maxmoney=="all" and minmoney=="all" : # 전체 목록     
        for c in checked_city:
            city_fitered=Auction_data.objects.filter(address__icontains=c)
            for i in A_L_result:
                obj=city_fitered.filter(address__icontains=i).order_by('usage').values()
                for j in obj:
                    a=re.search(r'\]',j["address"]).end()
                    A_L_list.append({"id": j["id"],"case":"\n".join(j["case"].split()) , "usage":j["usage"].split()[1] , "address": j["address"][0:a] ,"value":j["value"] , "date": j["date"] })
    
    elif (maxmoney=="all" and minmoney != "all" ): # minmoney만 주어졌을경우
        for c in checked_city:
            city_fitered=Auction_data.objects.filter(address__icontains=c)
            for i in A_L_result:
                obj=city_fitered.filter(address__icontains=i).order_by('usage').values()
                for j in obj:
                    esti_val=int("".join(j["value"].split()[0].split(",")))
                    if esti_val>=moneymin :
                        a=re.search(r'\]',j["address"]).end()
                        A_L_list.append({"id": j["id"],"case":"\n".join(j["case"].split()) , "usage":j["usage"].split()[1] , "address": j["address"][0:a] ,"value":j["value"] , "date": j["date"] })


    elif maxmoney!="all" and minmoney =="all" : # maxmoney만 주어졌을경우 
        for c in checked_city:
            city_fitered=Auction_data.objects.filter(address__icontains=c)
            for i in A_L_result:
                obj=city_fitered.filter(address__icontains=i).order_by('usage').values()
                for j in obj:
                    esti_val=int("".join(j["value"].split()[0].split(",")))
                    if esti_val<=moneymax :
                        a=re.search(r'\]',j["address"]).end()
                        A_L_list.append({"id": j["id"],"case":"\n".join(j["case"].split()) , "usage":j["usage"].split()[1] , "address": j["address"][0:a] ,"value":j["value"] , "date": j["date"] })
    html= "auction/auction_list.html"
    return render(request, html, { "A_L_list": A_L_list })
 

def auction_table(request):
    from pathlib import Path
    home = str(Path.home())
    
    A_T_list=request.POST.getlist('check')
    filename=request.POST.get('file')
    
    with open(home+"/"+filename+'.txt' , "wt" , encoding="utf8") as f:
        for id in A_T_list:
            selected_data=Auction_data.objects.get(id=id)
            print(selected_data.id , file=f )
            print("-"*30, file=f)
            print(selected_data.case , file=f)
            print("-"*30, file=f)
            print(selected_data.usage , file=f )
            print("-"*30, file=f)
            print(selected_data.address , file=f )
            print("-"*30, file=f)
            print(selected_data.value , file=f )
            print("-"*30, file=f)
            print(selected_data.other , file=f )
            print("="*30, file=f)
            print(" "*30, file=f)              
    html= "auction/auction_table.html"
    return render(request, html, { "A_T_list": A_T_list })

"""
path('admin/', admin.site.urls),
path('auction/', Myview.as_view()),  # path("url", CLSname.as_view() ) url을 CLS or func를 통하여 처리 .  
    path('auction/result', city_result ),
    path('auction/result/auctionlist', auction_result ),
    path('auction/result/auctionlist/<int:acution_data_id>', auction_detail ),
    path('auction/result/auctionlist/bag', auction_bag ),
django 에서는 html template 에서 dict[key] 방식을 허용하지 않는다. // dict.key 방식을 사용. 



        inst_val1=[]
        inst_val2=[]
        for m in obj:
           inst_val1.append(int("".join(m["value"].split()[0].split(",")))) # 감정평가액
           inst_val2.append(int("".join(m["value"].split()[1].split(","))))# 최저매각가격
        step=(max(inst_val1)-min(inst_val1))//10
        city_value_dict[i+"eval1"]=list(range(min(inst_val1),max(inst_val1)+step,step))
        step=(max(inst_val2)-min(inst_val2))//10
        city_value_dict[i]=list(range(min(inst_val2),max(inst_val2)+step,step))



"""


# render(request, 'movie_current/movie.html', {'movie_list': movie_list})
# render(request, "template html ", {"반환시 사용할 변수이름":변수})
# view - model을 읽어서 queryset으로 정리해서 반환// 



# Auction_data.objects.filter(icontains.. )values() # queryset -> iter -> set() -> list // each city and each 구 has to be classifed 
# 자주 사용되는 list는 db에 저장해버리는게 더 나을려나 ? .. form 에서 불러올때마다 새롭게 연산 ? // 이러한 물음에 대답을 해주는 사람이 없으면 안되... 사실 


"""
conn = sqlite3.connect(r'..\db.sqlite3')
curs = conn.cursor()    
a=curs.execute("SELECT * FROM movie_current_moviedata")
movie_list=a.fetchall() # 이걸 매번 정의해놓고 쓰기 좀 부담스럽지 않니 ? // 흠 .. 그래도.. auction - app // 
conn.close()
 a=Auction_data.objects.values('address')
 a=Auction_data.objects.filter(address__icontains="")values('address') -> address query set 반환 

for i in a:
    adlist.append(i["address"].strip().split()[0]) # 리스트로 재 정의후 사용이 나음.. 
"""