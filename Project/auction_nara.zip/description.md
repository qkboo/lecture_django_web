## django

---

```
views.py - models에서 불러와서 가공 후 template html에 변수를 지정 , url에 반환 한다고 생각하자  
models.py - db저장 및 불러오기. 
url.py - view에서 처리 함수 or 클래스를 사용할 url path를 지정.  
templates/app_name/base.html - 기본 틀 

```

#### url.py 

 - 기초 
```python
# 
from django.urls import path
from . import views


urlpatterns = [
    path('articles/2003/', views.special_case_2003), # # views.py 에 정의 된 special_case_2003 를 처리함수로 사용
    path('articles/<int:year>/', views.year_archive),
    path('articles/<int:year>/<int:month>/', views.month_archive), 
    path('articles/<int:year>/<int:month>/<slug:slug>/', views.article_detail),
] 
# A request to /articles/2005/03/ would match the third entry in the list. 
# Django would call the function views.month_archive(request, year=2005, month=3).


urlpatterns = [
    path('articles/2003/', views.special_case_2003),
    re_path(r'^articles/(?P<year>[0-9]{4})/$', views.year_archive),
    re_path(r'^articles/(?P<year>[0-9]{4})/(?P<month>[0-9]{2})/$', views.month_archive), # (?P<name>pattern),
    re_path(r'^articles/(?P<year>[0-9]{4})/(?P<month>[0-9]{2})/(?P<slug>[\w-]+)/$', views.article_detail),
```


```python urls.py
from django.urls import path

from . import views

urlpatterns = [
    #...
    path('articles/<int:year>/', views.year_archive, name='news-year-archive'),
    #...
]
```



```html 
<a href="{% url 'news-year-archive' 2012 %}">2012 Archive</a>
{# Or with the year in a template context variable: #}

<ul>
{% for yearvar in year_list %}
<li><a href="{% url 'news-year-archive' yearvar %}">{{ yearvar }} Archive</a></li>
{% endfor %}
</ul>
```

```
선적항
 경기도
 울산광역시
 광구소재지
 사용본거지
 세종특별자치시
 충청북도
 인천광역시
 경상남도
 충청남도
 전라북도
 전라남도
 대전광역시
 서울특별시
 제주특별자치도
 광주광역시
 소재지
 부산광역시
 제주도
 경상북도
 대구광역시
 강원도
```

```html
<form action="/auction/result" method="POST"> 
# action을 누르면 그 url로 이동 및 전달 
    매물을 찾을 지역을 골라주세요.<br>   
    {% csrf_token %}
    {% for city in ad_city_li %}
    <div>
        <input type="checkbox" id="citycheck" name='citycheck', value={{city}}>
        <label for="citycheck">{{city}}</label>
    </div>
      
    {% endfor %}
    <input type="submit" value="submit">
</form>


```
