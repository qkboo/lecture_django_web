import requests
from bs4 import BeautifulSoup
import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import os
import sys
## Python이 실행될 때 DJANGO_SETTINGS_MODULE이라는 환경 변수에 현재 프로젝트의 settings.py파일 경로를 등록합니다.
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "auction_nara.settings")
## 이제 장고를 가져와 장고 프로젝트를 사용할 수 있도록 환경을 만듭니다.
import django
django.setup()
from auction.models import Auction_data

class Auction_info :
    case=[]
    usage=[]
    address=[]
    other=[]
    value=[]
    date=[]

allinfo=Auction_info()
def parse_auction():
    for n in range(59):
        options = webdriver.ChromeOptions()
        driver = webdriver.Chrome(options=options)
        driver.get("https://www.courtauction.go.kr/InitMulSrch.laf?_CUR_CMD=InitMulSrch.laf&_CUR_SRNID=PNO102007&_FORM_YN=N&_NEXT_CMD=InitMulSrch.laf&_NEXT_SRNID=PNO102007&_SRCH_SRNID=PNO102007")
        elem=driver.find_element_by_id("idJiwonNm")
        elem.click()
        for i in range(n):
            elem.send_keys(Keys.ARROW_DOWN)
            time.sleep(1)
            
        elem.click()        
        elem = driver.find_element_by_xpath('//*[@id="contents"]/form/div/a[1]/img') # 검색버튼
        elem.click()
        soup = BeautifulSoup(driver.page_source, "html.parser")
        auctions = soup.find("tbody").find_all("tr")
        for item in auctions:
            if item.find_all("td")[0].text=="검색결과가 없습니다.":
                pass
            else :
                c=[]
                for i in item.find_all("td")[1].text.split("\n"):
                    c.append(i.strip())
                allinfo.case.append(" ".join(c))
                c=[]
                for i in item.find_all("td")[2].text.split("\n"):
                    c.append(i.strip())
                allinfo.usage.append(" ".join(c))
                c=[]
                for i in item.find_all("td")[3].text.split("\n"):
                    c.append(i.strip())
                allinfo.address.append(" ".join(c))
                c=[]
                for i in item.find_all("td")[4].text.split("\n"):
                    c.append(i.strip())
                allinfo.other.append(" ".join(c))
                c=[]
                for i in item.find_all("td")[5].text.split("\n"):
                    c.append(i.strip())
                allinfo.value.append(" ".join(c))
                c=[]
                for i in item.find_all("td")[6].text.split("\n"):
                    c.append(i.strip())
                allinfo.date.append(" ".join(c))
                
        try:
            lent=soup.find("div",attrs={"class":"page2"}).find_all("a")
            for i in range(1,len(lent)):
                elem=driver.find_element_by_xpath('//*[@id="contents"]/div[4]/form[2]/div/div[1]/a[{}]'.format(i)) # 페이지 넘기기 
                elem.click()
                time.sleep(1.5)
                soup = BeautifulSoup(driver.page_source, "html.parser")
                auctions = soup.find("tbody").find_all("tr")
                for item in auctions:
                    c=[]
                    for i in item.find_all("td")[1].text.split("\n"):
                        c.append(i.strip())
                    allinfo.case.append(" ".join(c))
                    c=[]
                    for i in item.find_all("td")[2].text.split("\n"):
                        c.append(i.strip())
                    allinfo.usage.append(" ".join(c))
                    c=[]
                    for i in item.find_all("td")[3].text.split("\n"):
                        c.append(i.strip())
                    allinfo.address.append(" ".join(c))
                    c=[]
                    for i in item.find_all("td")[4].text.split("\n"):
                        c.append(i.strip())
                    allinfo.other.append(" ".join(c))
                    c=[]
                    for i in item.find_all("td")[5].text.split("\n"):
                        c.append(i.strip())
                    allinfo.value.append(" ".join(c))
                    c=[]
                    for i in item.find_all("td")[6].text.split("\n"):
                        c.append(i.strip())
                    allinfo.date.append(" ".join(c))

                elem=driver.find_element_by_xpath('//*[@id="contents"]/div[4]/form[2]/div/div[1]/a[1]') 
                elem.click()
                time.sleep(1.5)
        except AttributeError:
            pass 
            

            
        driver.quit()

if __name__=='__main__':
    parse_auction()
    for a,b,c,d,e,f in zip(allinfo.case,allinfo.usage,allinfo.address,allinfo.other,allinfo.value,allinfo.date):
        print(a)
        print("*"*30)
        print(b)
        print("*"*30)
        print(c)
        print("*"*30)
        print(d)
        print("*"*30)
        print(e)
        print("*"*30)
        print(f)
        print("*"*30)
        print(" "*30)
        print(" "*30)
        time.sleep(10)
"""
for a,b,c,d,e,f in zip(allinfo.case,allinfo.usage,allinfo.address,allinfo.other,allinfo.value,allinfo.date):
    Auction_data(case=a,usage=b,address=c,other=d,value=e,date=f).save()
"""


    