import requests
from bs4 import BeautifulSoup
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mini_project.settings")
import django
django.setup()
# BlogData를 import해옵니다
from psychological_checks.models import Anxiety



def parseAnxiety():
    response = requests.get('http://www.openmind12.com/%EA%B0%84%EB%8B%A8%ED%95%9C-%EC%8B%AC%EB%A6%AC%EA%B2%80%EC%82%AC/111888')

    html = response.text
    soup = BeautifulSoup(html, 'html.parser')
    tags = soup.select('div[class=txt_content] font[size="4"]')
    tempLi= []
    for tag in tags:
        tempLi.append(tag.text.strip())

    strQuestion = tempLi[0]
    tempLi = strQuestion.split('(\xa0\xa0)')
    anxietyQuestion = []

    tempLi2 =[]
    for temp in tempLi:
        tempLi2.append(temp.split('.')) 

    for i in range(18):
        anxietyQuestion.append(tempLi2[i][1])

    return anxietyQuestion


if __name__=='__main__':
    anxietyQuestion = parseAnxiety()
    for question  in anxietyQuestion:
        Anxiety(question=question).save()