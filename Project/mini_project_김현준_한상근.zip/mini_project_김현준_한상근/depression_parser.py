# parser.py
import requests
from bs4 import BeautifulSoup
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mini_project.settings")
import django
django.setup()
from psychological_checks.models import Depression
import re

def parseDepression():
    req = requests.get('http://openmind12.com/%EA%B0%84%EB%8B%A8%ED%95%9C-%EC%8B%AC%EB%A6%AC%EA%B2%80%EC%82%AC/111886')
    html = req.text
    soup = BeautifulSoup(html, 'html.parser')
    my_questions = soup.select(
        'div > div > div > div > div > div > div > div > div > div > div > div > div > p > font'
        )
    my_questions = ''.join(map(str, my_questions))
    my_questions = my_questions.replace('<br/>', '').replace('\xa0', '').replace('  ',' ')
    my_questions = re.findall(r'\d+[.][\s가-힣\w]+', my_questions)

    tempLi = []
    for question in my_questions[3:13]:
        tempLi.append(question.split('. '))
    for question in my_questions[13:14]:
        tempLi.append(question.split('.'))
    for question in my_questions[14:]:
        tempLi.append(question.split('. '))

    depressionQuestion = []
    for question in tempLi:
        depressionQuestion.append(question[1])

    return depressionQuestion
    #for question in my_questions:
    #    data[question.text] = question.get('text')
    #return data

# 이 명령어는 이 파일이 import가 아닌 python에서 직접 실행할 경우에만 아래 코드가 동작하도록 합니다.
if __name__=='__main__':
    depressionQuestion = parseDepression()
    for question in depressionQuestion:
        Depression(question=question).save()