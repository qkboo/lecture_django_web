import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mini_project.settings")
import django
django.setup()

import csv
import pandas as pd
from psychological_checks.models import Hospital

def gathering_hospital_data():
    f = open('C:/Users/sangg/Desktop/Django/mini_project/hospital/hospital.csv', 'r', encoding = 'cp949')
    lines = csv.reader(f)

    keys = next(lines)
    data = {}
    number_of_data = 0

    for key in keys:
        data[key] = []
    for line in lines:
        key_index=0
        number_of_data += 1
        for key in keys:
            data[key].append(line[key_index])
            key_index +=1

    Hospital.objects.all().delete()

    frame = pd.DataFrame(data)

    for i in range(number_of_data):
        if '정신' in frame.loc[i,'요양기관명']:
            Hospital(name=frame.loc[i,'요양기관명'], phone=frame.loc[i,'전화번호'],\
                address=frame.loc[i,'주소'], city1=frame.loc[i,'시도코드명'], city2=frame.loc[i,'시군구코드명']).save()
    f.close()


if __name__ == '__main__':
    gathering_hospital_data()

