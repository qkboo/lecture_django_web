from django.contrib import admin
from psychological_checks.models import Depression, Anxiety, Depression_Score, Anxiety_Score, Profile, Hospital, HospitalUpdate

# Register your models here.

admin.site.register(Depression)
admin.site.register(Anxiety)
admin.site.register(Depression_Score)
admin.site.register(Anxiety_Score)
admin.site.register(Profile)
admin.site.register(Hospital)
admin.site.register(HospitalUpdate)