from django.apps import AppConfig


class PsychologicalChecksConfig(AppConfig):
    name = 'psychological_checks'
