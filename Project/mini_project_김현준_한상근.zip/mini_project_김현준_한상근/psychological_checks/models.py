from django.db import models
from django.core.files.storage import FileSystemStorage
from django.contrib.auth.models import User
from django.conf import settings
import os

import csv
import pandas as pd

# Create your models here.

class Depression(models.Model):
    question = models.CharField(max_length=250)

    def __str__(self):
        return self.question


class Anxiety(models.Model):
    question = models.CharField(max_length=250)

    def __str__(self):
        return self.question


class Depression_Score(models.Model):
    score = models.IntegerField()
    agreement = models.CharField(max_length=40)
    depression = models.ManyToManyField('Depression')

    def __str__(self):
        return str(self.agreement)

class Anxiety_Score(models.Model):
    score = models.IntegerField()
    agreement = models.CharField(max_length=40)
    anxiety = models.ManyToManyField('Anxiety')

    def __str__(self):
        return str(self.agreement)



class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    user_name = models.CharField(max_length=30)
    user_address = models.CharField(max_length=250) #근처 병원 정보 제공 위함

    def __str__(self):
        return str(self.user)


class Hospital(models.Model):
    name = models.CharField(max_length=50)
    phone = models.CharField(max_length=30)
    address = models.CharField(max_length=200)
    city1 = models.CharField(max_length=30) #시도
    city2 = models.CharField(max_length=30) #시군구


class OverwriteStorage(FileSystemStorage):
    '''
    file 같은 이름 존재할 경우 overwrite
    '''
    def get_available_name(self, name, max_length=None):
        if self.exists(name):
            os.remove(os.path.join(settings.MEDIA_ROOT, name))
        return name

class HospitalUpdate(models.Model):
    hospitals = models.FileField(upload_to='psychological_checks', storage=OverwriteStorage())

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        
        f = open('hospital.csv', 'r', encoding = 'cp949')

        lines = csv.reader(f)

        keys = next(lines)
        data = {}
        number_of_data = 0

        for key in keys:
            data[key] = []
        for line in lines:
            key_index=0
            number_of_data += 1
            for key in keys:
                data[key].append(line[key_index])
                key_index +=1

        Hospital.objects.all().delete()

        frame = pd.DataFrame(data)

        for i in range(number_of_data):
            if '정신' in frame.loc[i,'요양기관명']:
                Hospital(name=frame.loc[i,'요양기관명'], phone=frame.loc[i,'전화번호'], address=frame.loc[i,'주소'], city1=frame.loc[i,'시도코드명'], city2=frame.loc[i,'시군구코드명']).save()
        f.close()
