from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

app_name = 'psychological_checks'

urlpatterns = [
    path('', views.CheckListsModelView.as_view(), name='index'),
    path('depression/', views.DepressionListModelView.as_view(), name = 'depression'),
    path('anxiety/', views.AnxietyListModelView.as_view(), name = 'anxiety'),
    path('anxiety/result/', views.anxiety_result, name = 'anxiety_result'), 
    path('depression/result/', views.depression_result, name = 'depression_result'),
    path('login/', auth_views.LoginView.as_view(template_name='psychological_checks/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('signup/', views.signup, name='signup'),
    path('user_modify/', views.user_modify, name='user_modify'),

]
