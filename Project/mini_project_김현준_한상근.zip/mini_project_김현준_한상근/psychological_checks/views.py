from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.views.generic.base import TemplateView
from django.views.generic import DetailView, ListView
from django.views.generic.edit import FormView
from django.views import View
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth.hashers import check_password
import re

#병원 업데이트용

from django.contrib.auth.models import User

from .models import Depression, Anxiety, Depression_Score, Anxiety_Score, Hospital, Profile

# Create your views here.

class CheckListsModelView(TemplateView):
    template_name = 'psychological_checks/index.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['model_list'] = ['Depression', 'Anxiety']
        return context


class DepressionListModelView(ListView):
    queryset = Depression.objects.all()
    template_name = 'psychological_checks/depression.html'


class AnxietyListModelView(ListView):
    model = Anxiety
    template_name = 'psychological_checks/anxiety.html'


@login_required
def depression_result(request):
    try:
        sum_score = 0
        question_all = Depression.objects.all()
        
        for question in question_all:
            selected_choice = question.depression_score_set.get(pk=request.POST[question.question])
            sum_score += selected_choice.score

        if sum_score < 23:
            message = '검사상 유의미한 수준의 우울은 확인되지 않습니다.'
            return render(request, 'psychological_checks/result.html', {'sum':sum_score,
                                                                        'message':message})

        if sum_score >= 23:
            message = '전문가의 도움이 필요한 상태입니다.'
            psychological_help = True
            hospitals = Hospital.objects.all()

            address_of_user = request.user.profile.user_address.split(' ')
            
            second_address = re.sub(r'[시군구]$', '', address_of_user[1])

            hospitals_for_user = Hospital.objects.filter(city1=address_of_user[0], city2__contains=second_address)


    except(KeyError, Depression_Score.DoesNotExist):
        return render(request, 'psychological_checks/depression.html', {'error_message':"You didn't select a choice",
                                                                        'object_list':question_all})

    return render(request, 'psychological_checks/result.html', {'sum':sum_score,
                                                                'message':message,
                                                                'psychological_help':psychological_help,
                                                                'hospitals':hospitals_for_user})


@login_required
def anxiety_result(request):
    try:
        sum_score = 0
        question_all = Anxiety.objects.all()
        
        for question in question_all:
            selected_choice = question.anxiety_score_set.get(pk=request.POST[question.question])
            sum_score += selected_choice.score

        if sum_score < 6:
            message = '검사상 유의미한 수준의 불안은 확인되지 않습니다.'
            return render(request, 'psychological_checks/result.html', {'sum':sum_score,
                                                                        'message':message})

        if sum_score >= 6:
            message = '전문가의 도움이 필요한 상태입니다.'
            psychological_help = True
            hospitals = Hospital.objects.all()
            
            address_of_user = request.user.profile.user_address.split(' ')
            
            second_address = re.sub(r'[시군구]$', '', address_of_user[1])


            hospitals_for_user = Hospital.objects.filter(city1=address_of_user[0], city2__contains=second_address)




    except(KeyError, Depression_Score.DoesNotExist):
        return render(request, 'psychological_checks/anxiety.html', {'error_message':"You didn't select a choice",
                                                                        'object_list':question_all})

    return render(request, 'psychological_checks/result.html', {'sum':sum_score,
                                                                'message':message,
                                                                'psychological_help':psychological_help,
                                                                'hospitals':hospitals_for_user})




class LoginView(View):
    def post(self, request):
        data = json.loads(request.body)
        User(
            user_id     = data['user_id'],
            password    = data['password'],
            user_name = data['user_name'],
            user_address = data['user_address']
        )

        if User.objects.filter(user_id = data['user_id'], password = data['password']).exists() == True :
            return JsonResponse({"message": "로그인에 성공하셨습니다."}, status = 200)
        else:
            return JsonResponse({"message" : "아이디나 비밀번호가 일치하지 않습니다."}, status = 401)

    def get(self, request):
        user = User.objects.values()
        return JsonResponse({"list" : list(user)}, status = 200)



def signup(request):
    if request.method == "POST":
        user_all = User.objects.all()
        
        for one_user in user_all:
            if request.POST["username"] == one_user.username:
                error_message = "이미 있는 아이디입니다"
                return render(request, 'psychological_checks/signup.html', {'error_message': error_message})

        if request.POST["password1"] == request.POST["password2"]:
            user = User.objects.create_user(
                username=request.POST["username"],
                password=request.POST["password1"])
            user_name = request.POST["user_name"]
            user_address = request.POST["user_address"]
            profile = Profile(user=user, user_name=user_name, user_address=user_address )
            profile.save()
            login(request,user)
            return redirect('psychological_checks:index')

    return render(request, 'psychological_checks/signup.html')


def user_modify(request):
    if request.method == "POST":
        user = request.user
        pw_del = request.POST["password1"]
        if check_password(pw_del, user.password):
        #if request.POST["password1"] == user.password:
            user.profile.user_name = request.POST["user_name"]
            user.profile.user_address = request.POST["user_address"]
            user.profile.save()
            return redirect('psychological_checks:index')
        else:
            error_message = "비밀번호를 잘못 입력하셨습니다"
            return render(request, 'psychological_checks/user_modify.html', {'error_message':error_message,})



    return render(request, 'psychological_checks/user_modify.html')

